

<h1 class="page-header">
   All Products

</h1>
<table class="table table-hover">


    <thead>

      <tr>
           <th>Id</th>
           <th>Title</th>
           <th>Category</th>
           <th>Price</th>
      </tr>
    </thead>
    <tbody>

      <tr>
            <td>20</td>
            <td>Nikon 234 <br>
              <img src="http://placehold.it/62x62" alt="">
            </td>
            <td>Category</td>
            <td>123</td>
        </tr>
      


  </tbody>
</table>











                